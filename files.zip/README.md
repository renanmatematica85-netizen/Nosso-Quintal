# 📄 Organizador de NF-e

Sistema em Python que lê XMLs de Notas Fiscais Eletrônicas, extrai os dados principais e organiza tudo por mês/ano em Excel e CSV.

## ✅ O que faz

- Varre uma pasta (e subpastas) em busca de XMLs de NF-e
- Extrai automaticamente:
  - **CNPJ** do emitente e destinatário
  - **Valor total** da nota
  - **Data de emissão**
  - Número, série, natureza da operação, chave de acesso
- Organiza por **mês/ano**
- Gera relatório **Excel** com aba por mês + aba de resumo
- Gera **CSV** completo

## 📦 Instalação

```bash
pip install -r requirements.txt
```

## 🚀 Como usar

### 1. Gerar XMLs de exemplo (para testar)
```bash
python gerar_xml_exemplo.py
```

### 2. Processar os XMLs
```bash
# Usa a pasta padrão ./xmls e salva em ./relatorios
python organizador_nfe.py

# Especificar pastas personalizadas
python organizador_nfe.py /caminho/para/xmls -o /caminho/para/saida

# Com prefixo personalizado nos arquivos gerados
python organizador_nfe.py ./xmls -o ./relatorios -p empresa_x
```

## 📂 Estrutura de saída

```
relatorios/
├── nfe_organizadas.xlsx        # Excel com aba por mês/ano + resumo
└── nfe_todas_as_notas.csv     # CSV completo com todas as notas
```

### Excel gerado:
| Aba            | Conteúdo                              |
|----------------|---------------------------------------|
| Resumo Geral   | Total de notas e valor por mês/ano    |
| 2024-01        | Todas as notas de Janeiro/2024        |
| 2024-02        | Todas as notas de Fevereiro/2024      |
| ...            | ...                                   |

## 🔧 Compatibilidade de XML

Suporta NF-e versões **3.10** e **4.00** (padrão SEFAZ).

## 📋 Campos extraídos

| Campo                | Descrição                        |
|----------------------|----------------------------------|
| `chave_acesso`       | 44 dígitos identificadores       |
| `numero`             | Número da NF-e                   |
| `serie`              | Série da nota                    |
| `data_emissao`       | Data de emissão                  |
| `mes_ano`            | Mês/ano para agrupamento         |
| `cnpj_emitente`      | CNPJ formatado do emitente       |
| `nome_emitente`      | Razão social do emitente         |
| `doc_destinatario`   | CNPJ ou CPF do destinatário      |
| `nome_destinatario`  | Nome do destinatário             |
| `valor_total`        | Valor total da nota (R$)         |
| `natureza_op`        | Natureza da operação             |
| `arquivo_xml`        | Nome do arquivo de origem        |
