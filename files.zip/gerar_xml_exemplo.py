"""
Gerador de NF-e XML de exemplo para testes.
Cria 6 notas fiscais distribuídas em 3 meses.
"""

import os
from datetime import date

TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">
  <NFe>
    <infNFe Id="NFe{chave}" versao="4.00">
      <ide>
        <cUF>35</cUF>
        <nNF>{numero}</nNF>
        <serie>{serie}</serie>
        <natOp>{nat_op}</natOp>
        <dhEmi>{data}T10:00:00-03:00</dhEmi>
      </ide>
      <emit>
        <CNPJ>{cnpj_emit}</CNPJ>
        <xNome>{nome_emit}</xNome>
      </emit>
      <dest>
        <CNPJ>{cnpj_dest}</CNPJ>
        <xNome>{nome_dest}</xNome>
      </dest>
      <total>
        <ICMSTot>
          <vNF>{valor}</vNF>
        </ICMSTot>
      </total>
    </infNFe>
  </NFe>
</nfeProc>"""

NOTAS = [
    # Janeiro
    {"numero": "1001", "serie": "1", "data": "2024-01-10", "cnpj_emit": "12345678000195",
     "nome_emit": "Fornecedor Alpha LTDA", "cnpj_dest": "98765432000111", "nome_dest": "Empresa Beta S.A.",
     "valor": "1500.00", "nat_op": "Venda de mercadoria"},
    {"numero": "1002", "serie": "1", "data": "2024-01-22", "cnpj_emit": "11222333000181",
     "nome_emit": "Tech Solutions ME", "cnpj_dest": "98765432000111", "nome_dest": "Empresa Beta S.A.",
     "valor": "3200.50", "nat_op": "Prestação de serviço"},

    # Fevereiro
    {"numero": "2001", "serie": "1", "data": "2024-02-05", "cnpj_emit": "12345678000195",
     "nome_emit": "Fornecedor Alpha LTDA", "cnpj_dest": "55544433000122", "nome_dest": "Distribuidora Gama EIRELI",
     "valor": "870.00", "nat_op": "Venda de mercadoria"},
    {"numero": "2002", "serie": "2", "data": "2024-02-18", "cnpj_emit": "77788899000144",
     "nome_emit": "Indústria Delta S.A.", "cnpj_dest": "98765432000111", "nome_dest": "Empresa Beta S.A.",
     "valor": "12450.00", "nat_op": "Remessa para industrialização"},

    # Março
    {"numero": "3001", "serie": "1", "data": "2024-03-07", "cnpj_emit": "11222333000181",
     "nome_emit": "Tech Solutions ME", "cnpj_dest": "55544433000122", "nome_dest": "Distribuidora Gama EIRELI",
     "valor": "4800.00", "nat_op": "Prestação de serviço"},
    {"numero": "3002", "serie": "1", "data": "2024-03-29", "cnpj_emit": "12345678000195",
     "nome_emit": "Fornecedor Alpha LTDA", "cnpj_dest": "98765432000111", "nome_dest": "Empresa Beta S.A.",
     "valor": "2100.75", "nat_op": "Venda de mercadoria"},
]

if __name__ == "__main__":
    pasta = "./xmls"
    os.makedirs(pasta, exist_ok=True)

    for i, n in enumerate(NOTAS, 1):
        chave = f"{'3524' + n['data'].replace('-','') + n['cnpj_emit'] + n['numero']:0<44}"
        xml = TEMPLATE.format(chave=chave, **n)
        nome_arquivo = f"NF_{n['data']}_{n['numero']}.xml"
        with open(os.path.join(pasta, nome_arquivo), "w", encoding="utf-8") as f:
            f.write(xml)
        print(f"✅ Criado: {nome_arquivo}")

    print(f"\n📂 {len(NOTAS)} XMLs de exemplo criados em ./{pasta}/")
