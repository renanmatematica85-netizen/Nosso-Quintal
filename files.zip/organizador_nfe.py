"""
📄 Organizador de NF-e
======================
Lê XMLs de notas fiscais eletrônicas, extrai CNPJ, valor e data,
e organiza tudo por mês/ano em Excel e CSV.

Dependências: pip install pandas openpyxl lxml
"""

import os
import re
import glob
import argparse
from pathlib import Path
from datetime import datetime
import xml.etree.ElementTree as ET

import pandas as pd


# ──────────────────────────────────────────────
# Namespace padrão NF-e (versão 3.10 e 4.00)
# ──────────────────────────────────────────────
NS_NFE = {
    "nfe": "http://www.portalfiscal.inf.br/nfe"
}


def _find_text(root: ET.Element, xpath: str) -> str:
    """Retorna o texto de um elemento ou '' se não encontrado."""
    el = root.find(xpath, NS_NFE)
    return el.text.strip() if el is not None and el.text else ""


def formatar_cnpj(cnpj: str) -> str:
    """Formata string numérica para XX.XXX.XXX/XXXX-XX."""
    c = re.sub(r"\D", "", cnpj)
    if len(c) == 14:
        return f"{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}"
    return cnpj


def extrair_dados_xml(caminho_xml: str) -> dict | None:
    """
    Extrai os principais dados de um arquivo XML de NF-e.
    Retorna dict ou None se o arquivo não for uma NF-e válida.
    """
    try:
        tree = ET.parse(caminho_xml)
        root = tree.getroot()

        # Suporte a raízes com e sem namespace
        # Tenta encontrar o elemento 'infNFe' (coração da nota)
        inf_nfe = root.find(".//nfe:infNFe", NS_NFE)
        if inf_nfe is None:
            # Tenta sem namespace (algumas NF-e antigas)
            inf_nfe = root.find(".//infNFe")
        if inf_nfe is None:
            return None

        # ── Chave de acesso (44 dígitos) ──────────────────
        chave = inf_nfe.get("Id", "").replace("NFe", "")

        # ── Dados da emissão ──────────────────────────────
        dh_emi = _find_text(root, ".//nfe:ide/nfe:dhEmi") or \
                 _find_text(root, ".//nfe:ide/nfe:dEmi")
        if not dh_emi:
            return None

        # Converte para datetime (aceita datas com e sem fuso)
        dh_emi_clean = dh_emi[:10]  # pega só "YYYY-MM-DD"
        data_emissao = datetime.strptime(dh_emi_clean, "%Y-%m-%d")

        # ── Número e série ────────────────────────────────
        numero = _find_text(root, ".//nfe:ide/nfe:nNF")
        serie  = _find_text(root, ".//nfe:ide/nfe:serie")

        # ── Emitente ──────────────────────────────────────
        cnpj_emit = formatar_cnpj(_find_text(root, ".//nfe:emit/nfe:CNPJ"))
        nome_emit = _find_text(root, ".//nfe:emit/nfe:xNome") or \
                    _find_text(root, ".//nfe:emit/nfe:xFant")

        # ── Destinatário ──────────────────────────────────
        cnpj_dest = _find_text(root, ".//nfe:dest/nfe:CNPJ")
        cpf_dest  = _find_text(root, ".//nfe:dest/nfe:CPF")
        doc_dest  = formatar_cnpj(cnpj_dest) if cnpj_dest else cpf_dest
        nome_dest = _find_text(root, ".//nfe:dest/nfe:xNome")

        # ── Valor total ───────────────────────────────────
        valor_nf = _find_text(root, ".//nfe:total/nfe:ICMSTot/nfe:vNF")
        valor_nf = float(valor_nf) if valor_nf else 0.0

        # ── Natureza da operação ──────────────────────────
        nat_op = _find_text(root, ".//nfe:ide/nfe:natOp")

        return {
            "chave_acesso":   chave,
            "numero":         numero,
            "serie":          serie,
            "data_emissao":   data_emissao,
            "mes":            data_emissao.month,
            "ano":            data_emissao.year,
            "mes_ano":        data_emissao.strftime("%Y-%m"),
            "cnpj_emitente":  cnpj_emit,
            "nome_emitente":  nome_emit,
            "doc_destinatario": doc_dest,
            "nome_destinatario": nome_dest,
            "valor_total":    valor_nf,
            "natureza_op":    nat_op,
            "arquivo_xml":    os.path.basename(caminho_xml),
        }

    except ET.ParseError as e:
        print(f"  ⚠️  XML inválido [{os.path.basename(caminho_xml)}]: {e}")
        return None
    except Exception as e:
        print(f"  ⚠️  Erro [{os.path.basename(caminho_xml)}]: {e}")
        return None


def processar_pasta(pasta: str) -> pd.DataFrame:
    """Varre pasta recursivamente, processa todos os XMLs e retorna DataFrame."""
    xmls = glob.glob(os.path.join(pasta, "**", "*.xml"), recursive=True)
    xmls += glob.glob(os.path.join(pasta, "**", "*.XML"), recursive=True)
    xmls = list(set(xmls))  # remove duplicatas

    if not xmls:
        print(f"Nenhum arquivo XML encontrado em: {pasta}")
        return pd.DataFrame()

    print(f"\n🔍 Encontrados {len(xmls)} arquivo(s) XML — processando...\n")

    registros = []
    for i, xml_path in enumerate(sorted(xmls), 1):
        print(f"  [{i:>4}/{len(xmls)}] {os.path.basename(xml_path)}", end=" ")
        dados = extrair_dados_xml(xml_path)
        if dados:
            registros.append(dados)
            print("✅")
        else:
            print("❌ (não é NF-e ou inválido)")

    print(f"\n✅ {len(registros)} nota(s) processada(s) com sucesso.")
    return pd.DataFrame(registros)


def gerar_relatorio(df: pd.DataFrame, pasta_saida: str, prefixo: str = "nfe"):
    """Gera arquivos Excel e CSV organizados por mês/ano."""
    os.makedirs(pasta_saida, exist_ok=True)

    if df.empty:
        print("Nenhum dado para exportar.")
        return

    # ── Ordenação ─────────────────────────────────────────
    df = df.sort_values(["data_emissao", "numero"]).reset_index(drop=True)

    # ── CSV completo ──────────────────────────────────────
    csv_path = os.path.join(pasta_saida, f"{prefixo}_todas_as_notas.csv")
    df.to_csv(csv_path, index=False, encoding="utf-8-sig", sep=";")
    print(f"\n📄 CSV exportado → {csv_path}")

    # ── Excel com abas por mês/ano ─────────────────────────
    xlsx_path = os.path.join(pasta_saida, f"{prefixo}_organizadas.xlsx")
    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        # Aba "Resumo Geral"
        resumo = (
            df.groupby("mes_ano")
            .agg(
                qtd_notas=("chave_acesso", "count"),
                valor_total=("valor_total", "sum"),
            )
            .reset_index()
            .rename(columns={"mes_ano": "Mês/Ano", "qtd_notas": "Qtd. Notas", "valor_total": "Valor Total (R$)"})
        )
        resumo.to_excel(writer, sheet_name="Resumo Geral", index=False)
        _formatar_aba_excel(writer, "Resumo Geral", resumo)

        # Aba por mês/ano
        for mes_ano, grupo in df.groupby("mes_ano"):
            aba = mes_ano  # ex.: "2024-03"
            cols_exibir = [
                "numero", "serie", "data_emissao",
                "cnpj_emitente", "nome_emitente",
                "doc_destinatario", "nome_destinatario",
                "valor_total", "natureza_op", "arquivo_xml",
            ]
            grupo_export = grupo[cols_exibir].copy()
            grupo_export["data_emissao"] = grupo_export["data_emissao"].dt.strftime("%d/%m/%Y")
            grupo_export.to_excel(writer, sheet_name=aba, index=False)
            _formatar_aba_excel(writer, aba, grupo_export)

    print(f"📊 Excel exportado → {xlsx_path}")

    # ── Resumo no terminal ────────────────────────────────
    print("\n" + "═" * 50)
    print("📋 RESUMO POR MÊS/ANO")
    print("═" * 50)
    print(resumo.to_string(index=False))
    print("═" * 50)
    total_geral = df["valor_total"].sum()
    print(f"  Total geral: R$ {total_geral:>15,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
    print(f"  Notas processadas: {len(df)}")
    print("═" * 50 + "\n")


def _formatar_aba_excel(writer, nome_aba: str, df_aba: pd.DataFrame):
    """Ajusta largura das colunas automaticamente."""
    ws = writer.sheets[nome_aba]
    for col_idx, col in enumerate(df_aba.columns, 1):
        max_len = max(
            len(str(col)),
            df_aba[col].astype(str).str.len().max() if len(df_aba) > 0 else 0,
        )
        ws.column_dimensions[ws.cell(1, col_idx).column_letter].width = min(max_len + 4, 50)


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="📄 Organizador de NF-e — extrai CNPJ, valor e data de XMLs de notas fiscais"
    )
    parser.add_argument(
        "pasta",
        nargs="?",
        default="./xmls",
        help="Pasta com os arquivos XML das NF-e (padrão: ./xmls)",
    )
    parser.add_argument(
        "-o", "--output",
        default="./relatorios",
        help="Pasta de saída para os relatórios (padrão: ./relatorios)",
    )
    parser.add_argument(
        "-p", "--prefixo",
        default="nfe",
        help="Prefixo dos arquivos gerados (padrão: nfe)",
    )

    args = parser.parse_args()

    print("=" * 50)
    print("  📄 ORGANIZADOR DE NF-e")
    print("=" * 50)
    print(f"  Pasta de entrada: {os.path.abspath(args.pasta)}")
    print(f"  Pasta de saída:   {os.path.abspath(args.output)}")
    print("=" * 50)

    df = processar_pasta(args.pasta)
    gerar_relatorio(df, args.output, args.prefixo)


if __name__ == "__main__":
    main()
